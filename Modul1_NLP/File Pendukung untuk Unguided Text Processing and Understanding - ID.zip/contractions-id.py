# -*- coding: utf-8 -*-
"""
Created on Mon Aug 01 01:11:02 2016

@author: DIP
"""

CONTRACTION_MAP = {
"bkn": "bukan",
"otw": "sedang dalam perjalanan",
"oot": "diluar topik",
"fyi": "sebagai info saja",
"dg": "dengan",
"sjk": "sejak",
"hrga": "harga",
"pake": "pakai",
"dr": "dari",
"tkn": "tekan",
"utk": "untuk",
"dptkan": "dapatkan",
"vchr": "voucher"
}